#!/usr/bin/Rscript

AS_C05 <- read.csv("AllSites_C05.csv",header=TRUE,row.names=1)
Env <- read.csv("Env.csv",header=TRUE,row.names=1)	
pH <- Env$pH


library('mgcv')
library('picante')
library('gplots')
library('ggplot2')
library('RColorBrewer')
library('vegan')
library('ape')
library('GUniFrac')

AS <- t(AS_C05)
N <- rowSums(AS)
S <- specnumber(AS)
#Is species richness related to pH?
pdf("SpeciesRichness.pdf")
qplot(pH,S, geom=c("smooth","point"))+ xlab("pH") +  ylab("Species richness")
dev.off()

cor.test(pH,S)

summary(N)
S.rar <- rarefy(AS,482)
cor.test(pH,S.rar)
cor.test(pH,N)

S.lm <- lm(S ~ pH + C + N + CN + Moisture + LOI + vegetation, data = Env)
summary(S.lm)

Sh <-  diversity(AS, index = "shannon", MARGIN = 1, base = exp(1))
#Phylogentic diversity (PD) is a diversity measure that accounts for phylogenetic distance. Normalise frequency matrix and read in tree:
ASP <- AS/rowSums(AS)
tr <- read.tree("RAxML_bestTree.AllSite.tree")
#Calculate phylogentic diversity, plot, and test for significant relationship with pH (much higher!):


pd.result <- pd(ASP, tr, include.root = TRUE)

pdf("PhyloD.pdf")
qplot(pH,pd.result$PD, geom=c("smooth","point"))+ xlab("pH") +  ylab("Phylogenetic diversity")
dev.off()

cor.test(pH,pd.result$PD)

crp <- colorRampPalette(c("blue","red","orange","yellow"))(100)
ASPPH <- data.frame(ASP,pH)
ASPPH.order <- as.matrix(ASPPH[order(pH),])
ASPO <- ASPPH.order[,1:67]

pdf("HeatMap.pdf")
heatmap.2 (sqrt(ASPO),col=crp,trace="none",Rowv=FALSE,Colv=FALSE)
dev.off()

ASP.dist <- vegdist(ASP,dist="bray")

ASP.hclust <- hclust(ASP.dist, method = "ward")
pdf("ASP_hclust.pdf")
plot(ASP.hclust)
dev.off()

ASP.gunifrac <- GUniFrac(ASP, tr, alpha=c(0, 0.5, 1))$unifracs

#Extract weighted Unifrac distances:
ASP.uf <- ASP.gunifrac[,,"d_1"]

ASP.uf.cap <- capscale(ASP.uf ~ 1)
#Rescale pH to integers and make and bind pH like color palette:
IPH <- floor((pH - 3.5)*2) + 1
crp2 <- colorRampPalette(c("red","orange","green","blue","darkblue"))(14)
palette(crp2)

pdf("ASP_UF_CAP.pdf")
ordiplot (ASP.uf.cap, display = 'si', type = 'n')
for (i in seq (1, 14)) points (ASP.uf.cap, select = (IPH == i), col = i, pch = 19)
dev.off()

ASP.nmds <- metaMDS(ASP)
#Plot NMDS empty and add in sites coloured by pH:


pdf("ASP_nmds.pdf")
ordiplot (ASP.nmds, display = 'si', type = 'n')
for (i in seq (1, 14)) points (ASP.nmds, select = (IPH == i), col = i, pch = 19)
dev.off()

pdf("ASP_nmds_pH.pdf")
ordisurf(ASP.nmds, Env$pH)
for (i in seq (1, 14)) points (ASP.nmds, select = (IPH == i), col = i, pch = 19)
dev.off()

tr.phydist <- cophenetic(tr)

ASP.comdist <- comdist(ASP, tr.phydist,abundance.weighted=TRUE)

ASP.comdist.nmds <- metaMDS(ASP.comdist)

pdf("ASP_comdist.pdf")
ordiplot (ASP.comdist.nmds, display = 'si', type = 'n')
for (i in seq (1, 14)) points (ASP.comdist.nmds, select = (IPH == i), col = i, pch = 19)
dev.off()

ASP.ca <- cca(ASP)
#Select species with over 3,000 reads:
selSp <- colSums(AS)>3000
pdf("ASP_ca.pdf")
ordiplot (ASP.ca, display = 'si', type = 'n')
for (i in seq (1, 14)) points (ASP.ca, select = (IPH == i), col = i, pch = 19)
text(ASP.ca,display='sp',select=selSp)
dev.off()

#Use same cca function but include regression formula:

ASP.cca <- cca(ASP ~ pH + CN +  LOI + Moisture+ vegetation,data=Env)


anova(ASP.cca)

anova(ASP.cca, by="terms")

ASPR.cca <- cca(ASP~pH+LOI+vegetation,data=Env)
		
pdf("ASPR_cca.pdf")
ordiplot(ASPR.cca, display = 'si', type = 'n')
for (i in seq (1, 14)) points (ASPR.cca, select = (IPH == i), col = i, pch = 19)
text(ASPR.cca,"cn")

dev.off()


ASP.cap <- capscale(ASP ~ .,data=Env)
ASP.comdist.cap <- capscale(ASP.comdist ~ .,data=Env)
ASP.uf.cap <- capscale(ASP.uf ~ .,data=Env)

anova(ASP.comdist.cap)
anova(ASP.comdist.cap,perm.max=2000,perm=2000,by="terms")
anova(ASP.uf.cap,perm.max=2000,perm=2000,by="terms")
anova(ASP.cap,perm.max=2000,perm=2000,by="terms")
ASPR.uf.cap <- capscale(ASP.uf ~ pH + vegetation,data=Env)
pdf("ASP_UF_cap.pdf")
ordiplot(ASPR.uf.cap, display = 'si', type = 'n')
for (i in seq (1, 14)) points (ASPR.uf.cap, select = (IPH == i), col = i, pch = 19)
text(ASPR.uf.cap,"cn")
dev.off()

ASP.ado <- adonis(ASP ~ ., data=Env)
ASP.ado
#Compare to phylogenetically aware metric:
ASP.comdist.ado <- adonis(ASP.comdist ~ ., data=Env)
ASP.comdist.ado
#And Unifrac:
ASP.uf.ado <- adonis(ASP.uf ~ ., data=Env)
ASP.uf.ado

EnvN <- Env[,1:6]
EnvN.dist <- vegdist(scale(EnvN), "euclid")
mantel(ASP.dist,EnvN.dist)
mantel(ASP.uf,EnvN.dist)

sort(colSums(AS))
logASP <- log((AS+1)/rowSums(AS + 1))
#Pull out relative frequencies of three most abundant + C30:
logC6 <- logASP[,"C6"]
logC1 <- logASP[,"C1"]
logC13 <- logASP[,"C13"]
logC30 <- logASP[,"C30"]
#Use penalized generalized additive model to fit to relative frequencies:
logC6.gam<-gam(logC6~s(pH))
summary(logC6.gam)

pdf("logC6.gam.pdf")
plot(logC6.gam, xlab = "pH", ylab = "C6", las=0, pch=20, cex.axis=0.8, tck=0.01, cex.lab=0.85)
points(pH,logC6 - mean(logC6),pch=20)
dev.off()

nT <- ncol(logASP)
p <- rep(0,nT)

for(i in 1:nT){


	temp <-gam(logASP[,i]~s(pH))
	stemp <- summary(temp)
	p[i] <- stemp$s.table[[4]]
}

pa <- p.adjust(p, method = "BH")
hcp.df <- data.frame(colnames(logASP))
hcp.df <- cbind(hcp.df,p,pa)

